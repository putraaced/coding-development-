package cafe.app;

import cafe.model.Food;
import cafe.model.MainCourse;
import cafe.model.Dessert;
import cafe.exception.InvalidPriceException;

import java.util.ArrayList;
import java.util.Scanner;

public class CafeSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("================================================ validation =======");
        System.out.println("               ONLINE FOOD ORDERING SYSTEM");
        System.out.println("===================================================================");
        System.out.println();

        System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine().trim();
        System.out.println();

        // TASK 4: String Manipulation
        // i. Concatenate - Create a customer ID
        String customerID = "CUST-" + customerName;

        // ii. Substring - Extract first 3 characters
        String customerCode = "";
        if (customerName.length() >= 3) {
            customerCode = customerName.substring(0, 3);
        } else {
            customerCode = customerName;
        }

        // Length of customer name
        int nameLength = customerName.length();

        // TASK 7: ArrayList untuk menyimpan objek Food (Polimorfisme)
        ArrayList<Food> orderList = new ArrayList<>();
        ArrayList<Integer> quantityList = new ArrayList<>();

        try {
            // --- INPUT MAIN COURSE ---
            System.out.println("Enter Main Course:");
            System.out.print("Food Code: ");
            String mcCode = scanner.nextLine().trim();

            System.out.print("Food Name: ");
            String mcName = scanner.nextLine().trim();

            System.out.print("Price: ");
            double mcPrice = Double.parseDouble(scanner.nextLine().trim());

            System.out.print("Quantity: ");
            String mcQtyStr = scanner.nextLine().trim();
            // TASK 4 (iii): Convert Types - String ke int
            int mcQty = Integer.parseInt(mcQtyStr);
            System.out.println();

            // Cipta Objek MainCourse (Mencetuskan InvalidPriceException jika harga <= 0)
            MainCourse mainCourse = new MainCourse(mcCode, mcName, mcPrice);
            orderList.add(mainCourse);
            quantityList.add(mcQty);

            // --- INPUT DESSERT ---
            System.out.println("Enter Dessert:");
            System.out.print("Food Code: ");
            String dsCode = scanner.nextLine().trim();

            System.out.print("Food Name: ");
            String dsName = scanner.nextLine().trim();

            System.out.print("Price: ");
            double dsPrice = Double.parseDouble(scanner.nextLine().trim());

            System.out.print("Quantity: ");
            String dsQtyStr = scanner.nextLine().trim();
            // TASK 4 (iii): Convert Types - String ke int
            int dsQty = Integer.parseInt(dsQtyStr);
            System.out.println();

            // Cipta Objek Dessert
            Dessert dessert = new Dessert(dsCode, dsName, dsPrice);
            orderList.add(dessert);
            quantityList.add(dsQty);

            // TASK 5: Menggunakan StringBuffer untuk membina Order Summary
            StringBuffer summary = new StringBuffer();
            summary.append("====================== ORDER SUMMARY ==================\n\n");
            summary.append("Customer ID: ").append(customerID).append("\n");
            summary.append("Customer Code: ").append(customerCode).append("\n");
            summary.append("Name Length: ").append(nameLength).append("\n\n");
            summary.append("------------------------------------------- FOOD DETAILS ---------------------------------------\n");

            System.out.print(summary.toString());

            double grandTotal = 0.0;

            // TASK 7: Polimorfisme melalui ArrayList
            for (int i = 0; i < orderList.size(); i++) {
                Food food = orderList.get(i);
                int qty = quantityList.get(i);
                double itemTotal = food.calculateTotal(qty);
                grandTotal += itemTotal;

                System.out.println("Food Code: " + food.getFoodCode());
                System.out.println("Food Name: " + food.getFoodName());
                System.out.println("Quantity: " + qty);
                System.out.printf("Total: RM%.2f\n\n", itemTotal);
            }

            System.out.println("-----------------------------------------");
            System.out.printf("Grand Total: RM%.2f\n", grandTotal);
            System.out.println("-----------------------------------------");

        } catch (InvalidPriceException e) {
            // TASK 6: Handling Custom Exception
            System.out.println("Price Validation Error: " + e.getMessage());
        } catch (NumberFormatException e) {
            // TASK 6: Handling Invalid Input Format
            System.out.println("Input Error: Please enter a valid numerical value for price and quantity!");
        }

        scanner.close();
    }
}
