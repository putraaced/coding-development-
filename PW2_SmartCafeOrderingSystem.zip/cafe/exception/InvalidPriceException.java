package cafe.exception;

// Custom Exception untuk mengendalikan ralat harga tidak sah
public class InvalidPriceException extends Exception {
    public InvalidPriceException(String message) {
        super(message);
    }
}
