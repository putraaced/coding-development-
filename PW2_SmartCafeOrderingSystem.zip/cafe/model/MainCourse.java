package cafe.model;

import cafe.exception.InvalidPriceException;

// Subkelas MainCourse mewarisi Food (Task 3)
public class MainCourse extends Food {

    public MainCourse(String foodCode, String foodName, double price) throws InvalidPriceException {
        super(foodCode, foodName, price);
    }

    // Override abstract method calculateTotal
    @Override
    public double calculateTotal(int quantity) {
        return getPrice() * quantity;
    }
}
