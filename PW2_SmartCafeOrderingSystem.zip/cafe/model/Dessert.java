package cafe.model;

import cafe.exception.InvalidPriceException;

// Subkelas Dessert mewarisi Food (Task 3)
public class Dessert extends Food {

    public Dessert(String foodCode, String foodName, double price) throws InvalidPriceException {
        super(foodCode, foodName, price);
    }

    // Override abstract method calculateTotal (10% diskaun mengikut sampel output)
    @Override
    public double calculateTotal(int quantity) {
        return (getPrice() * quantity) * 0.90;
    }
}
