package cafe.model;

import cafe.exception.InvalidPriceException;

// Kelas Induk Abstrak (Task 2)
public abstract class Food {
    protected String foodCode;
    protected String foodName;
    protected double price;

    // Constructor untuk mengawali atribut
    public Food(String foodCode, String foodName, double price) throws InvalidPriceException {
        if (price <= 0) {
            throw new InvalidPriceException("Error: Price must be greater than RM 0.00!");
        }
        this.foodCode = foodCode;
        this.foodName = foodName;
        this.price = price;
    }

    // Getter methods
    public String getFoodCode() {
        return foodCode;
    }

    public String getFoodName() {
        return foodName;
    }

    public double getPrice() {
        return price;
    }

    // Setter method untuk harga dengan pengesahan
    public void setPrice(double price) throws InvalidPriceException {
        if (price <= 0) {
            throw new InvalidPriceException("Error: Price must be greater than RM 0.00!");
        }
        this.price = price;
    }

    // Abstract method wajib di-override oleh subkelas
    public abstract double calculateTotal(int quantity);

    // Normal method untuk memaparkan maklumat makanan
    public void displayFoodInfo() {
        System.out.println("Food Code: " + foodCode);
        System.out.println("Food Name: " + foodName);
        System.out.printf("Price    : RM%.2f\n", price);
    }
}
